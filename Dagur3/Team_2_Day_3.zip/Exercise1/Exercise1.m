close all; clear all; clc;
N = 40;
iterations = 2500;
TSP(N,iterations);