clear all, close all, clc
N = 50; % Number of rectangles
W = 6; % Width of the bin
iterations = 100;
PackandOpt(N,W,iterations);
