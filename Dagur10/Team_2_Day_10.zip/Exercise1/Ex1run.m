clear all; close all; clc;
%n=2
dimension = 2;
points2 = 1000*rand(50,dimension);
Exercise1(points2)
%n=3
dimension = 3;
points3 = 1000*rand(50,dimension);
Exercise1(points3)
%n=4
dimension = 4;
points4 = 1000*rand(50,dimension);
Exercise1(points4)
%n=5
dimension = 5;
points5 = 1000*rand(50,dimension);
Exercise1(points5)